<?php
function fecha_latina($fecha) {
    if ($fecha != '') {
        $afecha = explode(' ', $fecha);
        $hora = "";
        if(count($afecha)>1){
            $hora = $afecha[1];
        }
        $mifecha = explode('-', $afecha[0]);
        $lafecha = $mifecha[2] . "/" . $mifecha[1] . "/" . $mifecha[0];
        if($hora){
            $lafecha="$lafecha $hora";
        }
        return $lafecha;
    } else {
        return '';
    }
}

function fecha_iso($fecha) {
    if ($fecha != '') {
        $afecha = explode(' ', $fecha);
        $hora = "";
        if(count($afecha)>1){
            $hora = $afecha[1];
        }
        $mifecha = explode('/', $afecha[0]);
        $lafecha = $mifecha[2] . "-" . $mifecha[1] . "-" . $mifecha[0];
        if($hora){
            $lafecha="$lafecha $hora";
        }
        return $lafecha;
    } else {
        return '';
    }
}

function hora_minuto($hora){
    return Str::substr($hora, 0 , 5);
}

function paginacion($parPaginacion){
    return view('paginacion',['parPaginacion'=>$parPaginacion]);
}