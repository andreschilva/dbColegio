<?php
namespace App\Libs;
class Funciones 
{
    public static function fecha_iso($fecha_lat){
        return $fecha_lat;
    }
    public static function fecha_latina($fecha_iso){
        return $fecha_iso;
    }
}
